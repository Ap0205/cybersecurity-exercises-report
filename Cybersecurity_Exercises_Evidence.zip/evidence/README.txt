CYBERSECURITY EXERCISES — EVIDENCE
Student: Aayush Sharma
Practical date: 17 November 2026

This folder contains selected screenshots captured during the Kali Linux practical exercises.

Evidence index:
01–04  Tutorial 1: Linux command-line basics, file/process management, users/groups and system checks.
05–07  Tutorial 2: GPG key generation, encryption/decryption and corrected detached-signature verification.
08     Tutorial 3: MITM/public-key substitution detection by fingerprint comparison.
09     Tutorial 4: GPG secrets management, encryption and permissions.
10–11  Tutorial 5: Software-integrity verification and tamper detection, including final permission/checksum checks.

Safety note:
- Do not add private GPG keys, revocation certificates, plaintext secrets.env files,
  decrypted secrets, passwords.txt, or real credentials to a public GitHub repository.
- The screenshots are evidence images; they do not replace the full report.
- Review screenshots for personal information before making a public repository.
